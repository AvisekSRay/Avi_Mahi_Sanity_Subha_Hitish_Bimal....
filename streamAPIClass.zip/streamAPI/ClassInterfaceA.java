package com.basics.javatraining.streamAPI;

public class ClassInterfaceA  implements A{

	@Override
	public void m1() {
		System.out.println("Inside method m1 in ClassInterfaceA");
		
	}
	

}
class B implements A
{

	@Override
	public void m1() {
		System.out.println("Inside method m1 in Class B");
	}
	
}