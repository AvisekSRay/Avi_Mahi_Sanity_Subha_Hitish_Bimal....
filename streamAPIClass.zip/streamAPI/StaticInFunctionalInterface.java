package com.basics.javatraining.streamAPI;

public interface StaticInFunctionalInterface {
	public static void main(String[] args) {
		System.out.println("Hi naughty guys!");
	}

}
