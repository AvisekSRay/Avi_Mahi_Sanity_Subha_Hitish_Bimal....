package com.basics.javatraining.streamAPI;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class StreamAPITest1 {
	public static void main(String[] args) {
		int [] arr= {12,13,14,15,16,17,18,19};
		Arrays.stream(arr)
		.filter(num->num%2==0)
		.forEach(System.out::println);
		
		List<Integer> list=new ArrayList<Integer>();
		list.add(10);
		list.add(12);
		list.add(15);
		list.add(16);
		List<Integer> result=list.stream()
				.filter(num->num%2==0)
				.collect(Collectors.toList());
		System.out.println(result);
		
		list.stream()
		.filter(num->num%5==0)
		.forEach(System.out::println);
	}

}
