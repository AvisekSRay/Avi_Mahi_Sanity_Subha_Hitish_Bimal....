package com.basics.javatraining.streamAPI;

public class LambdaTest {

	public static void main(String[] args) {
		//method call using functional interface and lambda expression
		Z z1=()->System.out.println("Method one executed");
		z1.m1();
		
		X x1=(a,b)-> {return(a+b);};
		//int y=x1.m2(10, 20);
		System.out.println(x1.m2(10, 20));
		

	}

}
