package com.basics.javatraining.streamAPI;

public interface A {
	public void m1();
	
	default void m5()
	{
		System.out.println("Inside default m5");
	}
	static void m3()
	{
		System.out.println("Inside static m3 ");
	}
	

}
