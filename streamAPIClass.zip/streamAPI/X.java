package com.basics.javatraining.streamAPI;

public interface X {
	public int m2(int a1,int a2);

}
