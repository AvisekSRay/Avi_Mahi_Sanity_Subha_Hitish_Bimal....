package com.basics.javatraining.streamAPI;
@FunctionalInterface
public interface Z {
	void m1();

}
