package com.basics.javatraining.streamAPI;

public class TestA {

	public static void main(String[] args) {
		ClassInterfaceA a1=new ClassInterfaceA();
		B b1=new B();
		a1.m1();
		a1.m5();
		A.m3();
		b1.m1();
		b1.m5();

	}

}
