package atmmachine;

public class Customer {
	String customerName;
	Address address;
	int contactNo;
	Account account;
	Card card;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public int getContactNo() {
		return contactNo;
	}
	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public Card getCard() {
		return card;
	}
	public void setCard(Card card) {
		this.card = card;
	}
	
	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", address=" + address + ", contactNo=" + contactNo
				+ ", account=" + account.accountNumber + ", card=" + card.cardNumber + "]";
	}
	
	
}
