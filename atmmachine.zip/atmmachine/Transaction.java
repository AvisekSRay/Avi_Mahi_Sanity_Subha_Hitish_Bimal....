package atmmachine;

public class Transaction {
	double amount;
	Account account;
	Transaction(Account account)
	{
		this.account=account;
	}
	
	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
	

	
	public void deposit(){
		account.setBalance(account.getBalance()+amount);
		System.out.println("Sucessfully Deposited");
		System.out.println("Balance = "+account.getBalance());
		System.out.println("Thank You using our ATM");
		System.out.println("Go Green");
	}
	
	
	public void withdraw(){
		if(account.getBalance()>amount){
		account.setBalance(account.getBalance()-amount);
		System.out.println("Sucessfully Withdrawn");
		System.out.println("Balance = "+account.getBalance());
		System.out.println("Thank You using our ATM");
		System.out.println("Go Green");
		}
		else{
		System.out.println("Insufficent Funds");
		}
	}
}
