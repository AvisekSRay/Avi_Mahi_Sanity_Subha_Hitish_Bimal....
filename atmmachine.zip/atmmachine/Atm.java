package atmmachine;
import java.util.*;

public class Atm {

	public static void main(String[] args) {
		Card card=new Card();
		Customer customer=new Customer();
		Account account=new Account();
		Address address=new Address();
		Transaction transaction=new Transaction(account);
		Scanner sc = new Scanner(System.in);
		
		//Customer Details.
		customer.setCustomerName("Avisek");
		customer.setContactNo(97772629);
		customer.setAccount(account);
		customer.setAddress(address);
		customer.setCard(card);
		//Account Details.
		
		account.setBalance(500000);
		account.setAccountType(1);
		//Address.
		address.setCity("Cuttack");
		address.setCountry("India");
		address.setPin(754027);
		address.setState("Odisha");
		//Card
		card.setAccount(account);
		
		//account.setAccountType(1); // 1 for saving account and 2 for current account.
		
		
		
		System.out.println("Enter Your Account Number :");
		long cardNumber=sc.nextLong();
		System.out.println("Enter Pin");
		int pin = sc.nextInt();
		
		if(cardNumber == card.getCardNumber() && pin == card.getPin()){
			
			System.out.println(customer);
			System.out.println("Choose Transaction");
			System.out.println("1.Withdraw");
			System.out.println("2.Deposit");
			int Transactionchoice = sc.nextInt();
			
			switch(Transactionchoice){
			case 1:
				System.out.println("Enter the amount you want to withdraw");
				double withdrawAmount= sc.nextDouble();
				transaction.setAmount(withdrawAmount);
				transaction.withdraw();
				break;
			case 2:
				System.out.println("Enter the amount you want to deposit");
				double depositeAmount=sc.nextDouble();
				transaction.setAmount(depositeAmount);
				transaction.deposit();
				break;
			default :
				System.out.println("Thanks for using our Atm");
			}
			
		}
		else{
			System.out.println("Incorrect Pin & Card Number");
		}
		
	sc.close();
	}

}
