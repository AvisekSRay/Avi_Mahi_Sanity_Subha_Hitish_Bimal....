package atmmachine;
import java.util.*;

public class Account {
	Random rand = new Random();
	
	long accountNumber=rand.nextInt(1000000000);
	double balance=500000;
	int accountType;
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public long getAccountNumber(){
		return accountNumber;
	}
	
	public int getAccountType() {
		return accountType;
	}
	
	public void setAccountType(int accountType) {
		this.accountType = accountType;
	}

}
