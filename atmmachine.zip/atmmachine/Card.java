package atmmachine;

public class Card {
	long cardNumber=123456789;
	int pin=1212;
	Account account;
	
	public long getCardNumber() {
		return cardNumber;
	}
	
	public int getPin() {
		return pin;
	}
	
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	@Override
	public String toString() {
		return "Card [cardNumber=" + cardNumber + ", pin=" + pin + ", account=" + account + "]";
	}
}
